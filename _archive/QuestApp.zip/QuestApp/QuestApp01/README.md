# QuestApp01

This first release will cover the same workflow as the Python GUI. 

Rather than using a JSON file however, the QuestApp will instead be using a SQLite database file.
