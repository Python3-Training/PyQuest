/*
 * The time is right to create a better user interface!
 * The plan is to eventually offer BOTH a CLI, as well as a GUI.
 */
package com.soft9000.qna1;

/**
 *
 * @author profnagy
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JfrMain.main(args);
    }
    
}
