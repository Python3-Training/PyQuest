# QuestApp
It is time to create a GUI for the masses?

No longer a training exercise, here is the work-in-progress. (*)

If you are looking for 'that question sharing thing,' then QuestJSOB 'be [here](https://github.com/Python3-Training/PyQuest/tree/main/QuestJSOB).

If you need to prepare for an interview, then you may also enjoy our growing **PyQuest** series:

## zGroup
Here is [the Facebook group](https://www.facebook.com/PythonVideo/)

## zVideos
Here are [the Videos](https://soft9000.com)
- [Python 9000: Review Concepts (K1 thru K10)](https://www.udemy.com/course/python-interview-questions/?referralCode=6B199764132B575C503C)
- [Python 9000: Review Concepts (K11 thru K22)](https://www.udemy.com/course/nagys-python-review-k11-k22/?referralCode=2280C848244C9714E1E2)

## zBooks
Here are [the Amazon books](https://www.amazon.com/Randall-Nagy/e/B08ZJLH1VN/ref=aufs_dp_fta_dsk)

### PyQuest Books
Updated to 100 Q&A case studies the latest edition of **Python Interview Questions & Concepts** combines the content of **PyQuest Beginner**, **PyQuest Advanced**, 35 additional **PyQuest Intermediate** concepts as well as 5 more PyQuest Beginner questions, answers, and code demonstrations. The updated set of PyQuest cards are part of the companion PyQuest card deck, game, and flashcard book.

- [100 Python Questions](https://www.amazon.com/dp/B0BH97W78F)

We are also sharing the work-in-progress. An enumerated set of questions & answers 'Pythoneers can use to better prepare for professional exams & interviews [in this folder](https://github.com/Python3-Training/PyQuest/tree/master/QuestJSOB/KASeries/KA9000)

features | more

\o/

-- Randall

(*) NOTE: I am using Netbeans with JDK 8. The forms also work under the latest Apache.

## zSupport?
If you want to support the effort, I seek no donations. Instead, simply feel free to purchase one of [my educational](https://www.udemy.com/user/randallnagy2/) or [printed](https://www.amazon.com/Randall-Nagy/e/B08ZJLH1VN?ref=sr_ntt_srch_lnk_1&qid=1660050704&sr=8-1) productions?

